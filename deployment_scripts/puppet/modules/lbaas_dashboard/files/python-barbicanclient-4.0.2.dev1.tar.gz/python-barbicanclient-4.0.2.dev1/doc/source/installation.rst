============
Installation
============

At the command line::

    $ pip install python-barbicanclient

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-barbicanclient
    $ pip install python-barbicanclient